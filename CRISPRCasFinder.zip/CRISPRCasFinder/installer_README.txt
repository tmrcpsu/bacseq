# download manual from https://crisprcas.i2bc.paris-saclay.fr/Home/Download
# and follow installation guide chapter
