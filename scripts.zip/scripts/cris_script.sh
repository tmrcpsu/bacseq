#!/bin/bash -l
export PATH="$1/Software/biotools/CRISPRCasFinder/bin:$PATH"
rm -rf $1/Software/output/CRISPRCasFinder/*
for file_scaffold in $1/Software/output/Fasta/scaffolds/*.fasta; do

	file_cut=$(basename -- "$file_scaffold" .fasta)

#comments.when.some.file.name.missing
# filename=$(basename -- "$file_scafold" .fasta)
# extension="${filename##*.}"
# filename="${filename%%.*}"
# file_cut="${filename%_*}"

/usr/bin/perl $1/Software/biotools/CRISPRCasFinder/CRISPRCasFinder.pl -i ${file_scaffold} -out $1/Software/output/CRISPRCasFinder/${file_cut} -so $1/Software/biotools/CRISPRCasFinder/sel392v2.so -html
	done
