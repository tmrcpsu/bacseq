#!/bin/bash

qc_fol=$1/Software/output/FastQC

multiqc $qc_fol -f -o $1/Software/output/MultiQC

