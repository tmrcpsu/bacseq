#!/bin/bash
export PATH="$1/Software/biotools/CRISPRCasFinder/bin:$PATH"
filename="$1/Software/output/all_file_log.txt"
filename2="$1/Software/output/file_log.txt"
file_long="$1/Software/output/file_long.txt"
qc_fol=$1/Software/output/FastQC
R1_1="_1"
R2_1="_2"
R1_2="R1"
R2_2="R2"
R1_3="001"
R2_3="002"
counter2=0
op_contigs=$1/Software/output/quast/contigs
op_scaffolds=$1/Software/output/quast/scaffolds
fasta_check=$1/Software/output/Fasta/scaffolds
assembler_option=${3}
#FastQC
if [ -z "$(ls -A ${fasta_check})" ]; then
while read p; do
	counter=$((counter+1))

	filename=$(basename -- "$p")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"


if [ -d "$1/Software/output/FastQC/${filename1}" ] 
then
    echo "Directory $1/Software/output/FastQC/${filename1} exists." 
else

    echo "Directory $1/Software/output/FastQC/${filename1} does not exists, Creating Directory..."
    mkdir $1/Software/output/FastQC/${filename1}
fi

$1/Software/biotools/FastQC/./fastqc -t ${2} $p --outdir=$1/Software/output/FastQC/${filename1}

# done

	done < $filename

#MultiQC


multiqc $qc_fol -f -o $1/Software/output/MultiQC


#Fastp
if [ -s ${filename2} ];then
while read p; do
	counter=$((counter+1))
	filename=$(basename -- "$p")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"


for file1 in $p; do

file2=${file1/_1/_2}

echo $file1 $file2
mkdir $1/Software/output/fastp/${filename1}
cd $1/Software/output/fastp/${filename1}
fastp -i ${file1} -I ${file2} -o out_${filename1}_1.fastq.gz -O out_${filename1}_2.fastq.gz -w ${2} --html ${filename1}.html --json ${filename1}.json

done

	done < ${filename2}
fi
#### Long reads
if [ -s ${file_long} ];then
	echo "Found long reads file."
while read long; do
	counter=$((counter+1))
	
	filename=$(basename -- "$long")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"


for file_l_read in $long; do

filename_long=$(basename -- "$file_l_read" .fq.gz)
long_path="${file_l_read%%.*}"
mkdir $1/Software/output/fastp/${filename1}
cd $1/Software/output/fastp/${filename1}
fastp -i ${file_l_read} -o out_${filename1}.fastq.gz -w ${2} --html ${filename1}.html --json ${filename1}.json 
fastp -i ${long_path}_1long.fq.gz -I ${long_path}_2long.fq.gz -o out_${filename1}_1.fastq.gz -O out_${filename1}_2.fastq.gz -w ${2} --html ${filename1}_12.html --json ${filename1}_12.json

# unicycler --min_fasta_length 150 -t ${2} -o $1/Software/output/SPAdes/${filename1} -l ${file_l_read}
unicycler --min_fasta_length 150 -1 ${long_path}_1long.fq.gz -2 ${long_path}_2long.fq.gz -l ${file_l_read} -t ${2} -o $1/Software/output/SPAdes/${filename1}
cp $1/Software/output/SPAdes/${filename1}/assembly.fasta $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta
cd $1/Software/output/
cp $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta $1/Software/output/Fasta/scaffolds
done

	done < ${file_long}

fi

#SPAdes
if [ -s ${filename2} ];then
if [[ "$assembler_option" == "SPAdes" ]]; then
	echo "SPAdes assembling..."
while read p; do
	counter2=$((counter+1))
	
	filename=$(basename -- "$p")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"

for file1 in ${p}; do

file2=${file1/_1/_2}

echo $file1 $file2
python3 $1/Software/biotools/SPAdes/bin/spades.py --cov-cutoff auto -t ${2} -o $1/Software/output/SPAdes/${filename1} -1 ${file1} -2 ${file2} --careful  --only-assembler -m 1000
cp $1/Software/output/SPAdes/${filename1}/scaffolds.fasta $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta
cp $1/Software/output/SPAdes/${filename1}/contigs.fasta $1/Software/output/SPAdes/${filename1}/${filename1}.contigs.fasta
cd $1/Software/output/
cp $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta $1/Software/output/Fasta/scaffolds
cp $1/Software/output/SPAdes/${filename1}/${filename1}.contigs.fasta $1/Software/output/Fasta/contigs

done
	done < ${filename2}
	elif [[ "$assembler_option" == "Unicycler" ]]; then 

	echo "Unicycler assembling..."

while read p; do
	counter=$((counter+1))
	
	filename=$(basename -- "$p")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"


for file1 in $p; do

file2=${file1/_1/_2}

echo $file1 $file2
unicycler  --min_fasta_length 150 -t ${2} -o $1/Software/output/SPAdes/${filename1} -1 ${file1} -2 ${file2} 
cp $1/Software/output/SPAdes/${filename1}/assembly.fasta $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta
cd $1/Software/output/
cp $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta $1/Software/output/Fasta/scaffolds

done

	done < ${filename2}

fi





fi
fi


#Quast
cd $1/Software/output/Fasta/scaffolds/

quast *.fasta -o ${op_scaffolds}/ --threads ${2}		
if [ -z "$(ls -A $1/Software/output/Fasta/contigs)" ]; then
	echo "Not found contigs files skipping..."
else
cd $1/Software/output/Fasta/contigs/
quast *.fasta -o ${op_contigs}/ --threads ${2}
fi
#Busco
for file_scaffold in ${fasta_check}/*.fasta; do

	file_cut=$(basename -- "$file_scaffold" .fasta)

#comments.when.some.file.name.missing
# filename=$(basename -- "$file_faa" faa)
# extension="${filename##*.}"
# filename="${filename%%.*}"
# file_cut="${filename%_*}"
cd $1/Software/output/busco/scaffolds/
busco -i $file_scaffold --out_path $1/Software/output/busco/scaffolds -o $file_cut -l bacteria_odb10 -f -c ${2} -m Genome 

cp $1/Software/output/busco/scaffolds/${file_cut}/short_summary.specific.bacteria_odb10.${file_cut}.txt $1/Software/output/busco/graph_plot/short_summary.specific.bacteria_odb10.${file_cut}.txt

cd $1/Software/output/busco/scaffolds/${file_cut}/run_bacteria_odb10/
sed '1,2d' full_table.tsv > ${file_cut}_full_table.tsv
bash $1/Software/biotools/scripts/html_script/busco_html_script.sh "${1}" "${file_cut}" > $1/Software/output/busco/visualization/${file_cut}.html
	done



generate_plot.py -wd $1/Software/output/busco/graph_plot



#Prokka
for file_scaffold in ${fasta_check}/*.fasta; do

	filename1=$(basename -- "$file_scaffold" .fasta)

#comments.when.some.file.name.missing
# filename1=$(basename -- "$file_scaffold")
# extension="${filename##*.}"
# filename="${filename%%.*}"
# filename1="${filename%_*}"
	prokka --outdir $1/Software/output/prokka/${filename1} --force --addgenes --prefix ${filename1} \
	 --cpus ${2} $file_scaffold
cp $1/Software/output/prokka/${filename1}/${filename1}.gff $1/Software/output/gff

cd $1/Software/output/prokka/${filename1} 
sed 's/^\t/NA\t/;s/\t$/\tNA/;:0 s/\t\t/\tNA\t/;t0' ${filename1}.tsv >  ${filename1}_edited.tsv

bash $1/Software/biotools/scripts/html_script/prokka_html_script.sh "${1}" "${filename1}" > $1/Software/output/prokka/${filename1}/${filename1}.html
		
	done

#Prokka Chart
bash $1/Software/biotools/scripts/html_script/prokka_chart.sh "${1}" > $1/Software/output/prokka/prokka_chart.html	

bash $1/Software/biotools/scripts/html_script/prokka_summary.sh "${1}" > $1/Software/output/prokka/prokka_summary.html


#eggNOG
eggnog_path=${1}/Software/biotools/eggnog-mapper/data
 if [ -d "${eggnog_path}" ];
 then
for file_faa in $1/Software/output/prokka/*/*.faa; do

	file_cut=$(basename -- "$file_faa" .faa)

#comments.when.some.file.name.missing
# filename1=$(basename -- "$file_scaffold")
# extension="${filename##*.}"
# filename="${filename%%.*}"
# filename1="${filename%_*}"
echo "Eggnog-Mapper are running for ${file_cut}..."
mkdir $1/Software/output/eggnog-mapper/${file_cut}
cd $1/Software/output/eggnog-mapper/${file_cut}
emapper.py --data_dir $1/Software/biotools/eggnog-mapper/data -i ${file_faa} --output_dir $1/Software/output/eggnog-mapper/${file_cut} -o ${file_cut} --override --evalue 0.001 --score 60 --pident 40 --query_cover 20 --subject_cover 20 --itype proteins --tax_scope auto --target_orthologs all --go_evidence non-electronic --pfam_realign none --report_orthologs --decorate_gff yes --cpu ${2} --excel 
sed -i '1,4d' ${file_cut}.emapper.annotations
head -n -3 ${file_cut}.emapper.annotations  > ${file_cut}.emapper.tsv 

bash $1/Software/biotools/scripts/html_script/emapper_html_script.sh "${1}" "${file_cut}" > $1/Software/output/eggnog-mapper/${file_cut}/${file_cut}.html

	done
	else
	echo "EggNOG-mapper not installed. Skip this part..."
	fi

#Abricate
for file_scaffold in ${fasta_check}/*.fasta; do

	filename=$(basename -- "$file_scaffold" .fasta)
extension="${filename##*.}"
# filename="${filename%%.*}"
abricate --db ncbi --threads ${2} --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_ncbi_scaffolds_output.tab
abricate --db card -threads ${2} --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_card_scaffolds_output.tab
abricate --db resfinder -threads ${2} --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_resfinder_scaffolds_output.tab
abricate --db argannot -threads ${2} --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_argannot_scaffolds_output.tab
abricate --db megares -threads ${2} --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_megares_scaffolds_output.tab
abricate --db plasmidfinder -threads ${2} --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_plasmidfinder_scaffolds_output.tab
abricate --db vfdb -threads ${2} --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_vfdb_scaffolds_output.tab


	done

cd $1/Software/output/abricate/scaffolds/





ncbi_path="$1/Software/output/abricate/scaffolds/summary_ncbi.tsv"
abricate --summary *_ncbi_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_ncbi.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_ncbi.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${ncbi_path}" > $1/Software/output/abricate/html_scaffolds/Summary_ncbi.html


card_path="$1/Software/output/abricate/scaffolds/summary_card.tsv"
abricate --summary *_card_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_card.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_card.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${card_path}" > $1/Software/output/abricate/html_scaffolds/Summary_card.html

resfinder_path="$1/Software/output/abricate/scaffolds/summary_resfinder.tsv"
abricate --summary *_resfinder_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_resfinder.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_resfinder.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${resfinder_path}" > $1/Software/output/abricate/html_scaffolds/Summary_resfinder.html

argannot_path="$1/Software/output/abricate/scaffolds/summary_argannot.tsv"
abricate --summary *_argannot_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_argannot.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_argannot.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${argannot_path}" > $1/Software/output/abricate/html_scaffolds/Summary_argannot.html

megares_path="$1/Software/output/abricate/scaffolds/summary_megares.tsv"
abricate --summary *_megares_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_megares.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_megares.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${megares_path}" > $1/Software/output/abricate/html_scaffolds/Summary_megares.html

plasmidfinder_path="$1/Software/output/abricate/scaffolds/summary_plasmidfinder.tsv"
abricate --summary *_plasmidfinder_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_plasmidfinder.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_plasmidfinder.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${plasmidfinder_path}" > $1/Software/output/abricate/html_scaffolds/Summary_plasmidfinder.html

vfdb_path="$1/Software/output/abricate/scaffolds/summary_vfdb.tsv"
abricate --summary *_vfdb_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_vfdb.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_vfdb.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${vfdb_path}" > $1/Software/output/abricate/html_scaffolds/Summary_vfdb.html

sum_path="$1/Software/output/abricate/scaffolds/summary.tsv"
abricate --summary *.tab > $1/Software/output/abricate/scaffolds/summary.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${sum_path}" > $1/Software/output/abricate/html_scaffolds/Summary.html

export path_dir=$ncbi_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_ncbi.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_ncbi_files/

export path_dir=$card_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_card.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_card_files/


export path_dir=$resfinder_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_resfinder.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_resfinder_files/

export path_dir=$argannot_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_argannot.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_argannot_files/

export path_dir=$megares_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_megares.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_megares_files/

export path_dir=$plasmidfinder_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_plasmidfinder.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_plasmidfinder_files/

export path_dir=$vfdb_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_vfdb.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_vfdb_files/

export path_dir=$sum_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_summary.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_summary_files/


#StarAMR
contigs="contigs"
scaffolds="scaffolds"
cd $1/Software/output/staramr/
rm -rf scaffolds/
rm -rf contigs/ 
cd $1/Software/output/Fasta/scaffolds
staramr search -o $1/Software/output/staramr/scaffolds/ -n ${2} *.fasta
cd $1/Software/output/staramr/scaffolds/
sed -i 's/^\t/NA\t/;s/\t$/\tNA/;:0 s/\t\t/\tNA\t/;t0' detailed_summary.tsv 

	bash $1/Software/biotools/scripts/html_script/staramr_html_script.sh "${1}" "${scaffolds}" > $1/Software/output/staramr/scaffolds/staramr_scaffolds.html
	bash $1/Software/biotools/scripts/html_script/staramr_html_mlst_script.sh "${1}" "${scaffolds}" > $1/Software/output/staramr/scaffolds/staramr_mlst_scaffolds.html
	bash $1/Software/biotools/scripts/html_script/staramr_html_resfinder_script.sh "${1}" "${scaffolds}" > $1/Software/output/staramr/scaffolds/staramr_resfinder_scaffolds.html


if [ -z "$(ls -A $1/Software/output/Fasta/contigs)" ]; then
	echo "Not found contigs files skipping..."
else
cd $1/Software/output/Fasta/contigs
staramr search -o $1/Software/output/staramr/contigs/ -n ${2} *.fasta
cd $1/Software/output/staramr/contigs/
sed -i 's/^\t/NA\t/;s/\t$/\tNA/;:0 s/\t\t/\tNA\t/;t0' detailed_summary.tsv 
		bash $1/Software/biotools/scripts/html_script/staramr_html_script.sh "${1}" "${contigs}" > $1/Software/output/staramr/contigs/staramr_contigs.html
		bash $1/Software/biotools/scripts/html_script/staramr_html_mlst_script.sh "${1}" "${contigs}" > $1/Software/output/staramr/contigs/staramr_mlst_contigs.html
		bash $1/Software/biotools/scripts/html_script/staramr_html_resfinder_script.sh "${1}" "${contigs}" > $1/Software/output/staramr/contigs/staramr_resfinder_contigs.html
fi
#Run_dbcan
for file_faa in $1/Software/output/prokka/*/*.faa; do

	
file_cut=$(basename -- "$file_faa" .faa)

#comments.when.some.file.name.missing
# filename=$(basename -- "$file_faa" faa)
# extension="${filename##*.}"
# filename="${filename%%.*}"
# file_cut="${filename%_*}"

tools_string=${6}
tools_string=$(eval echo $tools_string)
echo "run_dbcan are running for ${file_cut}..."
echo ${file_faa}
run_dbcan ${file_faa} protein --out_dir $1/Software/output/run_dbcan/${file_cut} --db_dir $1/Software/biotools/dbcan_db --dia_cpu ${2} --hmm_cpu ${2} --dia_eval 1e-102 --hmm_eval 1e-15 --hmm_cov 0.35 -t {hmmer,diamond}
cd $1/Software/output/run_dbcan/${file_cut}
cp overview.txt overview.tsv
rm -r $1/home
bash $1/Software/biotools/scripts/html_script/rundbcan_html_script.sh "${1}" "${file_cut}" > $1/Software/output/run_dbcan/${file_cut}/${file_cut}.html
	done

# CRISPRCasFinder
rm -rf $1/Software/output/CRISPRCasFinder/*
for file_scaffold in ${fasta_check}/*.fasta; do

	file_cut=$(basename -- "$file_scaffold" .fasta)

#comments.when.some.file.name.missing
# filename=$(basename -- "$file_faa" faa)
# extension="${filename##*.}"
# filename="${filename%%.*}"
# file_cut="${filename%_*}"

/usr/bin/perl $1/Software/biotools/CRISPRCasFinder/CRISPRCasFinder.pl -i ${file_scaffold} -out $1/Software/output/CRISPRCasFinder/${file_cut} -so $1/Software/biotools/CRISPRCasFinder/sel392v2.so -html
	done


#Roary
rm -rf $1/Software/output/roary/
counter_roary=0
filename="$1/Software/output/file_log.txt"

for file in $1/Software/output/gff/*; do
	counter_roary=$((counter_roary+1))
	
# echo $counter
	done 

if [[ $counter_roary -gt 1 ]]
then
	echo "Passed"
cd $1/Software/output/gff
	roary --mafft -e -p ${2} -r -f $1/Software/output/roary/ -v *.gff
	
	cd $1/Software/output/roary/
	sed 's/\("\([^"]*\)"\)\?,/\2\t/g' gene_presence_absence.csv > gene_presence_absence_convert.tsv
	sed -i 's/\"//g' gene_presence_absence_convert.tsv
	sed -i 's/^\t/NA\t/;s/\t$/\tNA/;:0 s/\t\t/\tNA\t/;t0' gene_presence_absence_convert.tsv

	bash $1/Software/biotools/scripts/html_script/roary_html_script.sh "${1}" "${counter_roary}" > $1/Software/output/roary/gene_presence_absence_convert.html
	
else
	echo "Your GFF files must use at least 2 files" 
fi

if [[ $counter_roary -gt 1 ]]
then
#SNPsite
snp-sites -mvp -o $1/Software/output/snp_sites/core_gene_alignment.aln $1/Software/output/roary/*.aln
snp-sites -mvp -o $1/Software/output/snp_sites/accessory_binary_genes_.fa.aln $1/Software/output/roary/accessory_binary_genes.fa
#FastTree
$1/Software/biotools/./FastTree -nt -gtr $1/Software/output/snp_sites/core_gene_alignment.aln.snp_sites.aln > $1/Software/output/FastTree/my_tree.newick
$1/Software/biotools/./FastTree -nt -gtr $1/Software/output/snp_sites/accessory_binary_genes_.fa.aln.snp_sites.aln > $1/Software/output/FastTree/my_tree_accessory_binary_gene.newick

cd $1/Software/output/roary
python3 $1/Software/biotools/roary_plots/roary_plots.py $1/Software/output/roary/accessory_binary_genes.fa.newick $1/Software/output/roary/gene_presence_absence.csv

cd $1/Software/output/FastTree/

python3 $1/Software/biotools/scripts/python_script/tree.py
python3 $1/Software/biotools/scripts/python_script/tree2.py
else
 echo "Your roary result not found. Skipping..."
fi
bash $1/Software/biotools/scripts/html_script/create_index.sh "${1}" > $1/Software/output/results.html

now=$(date '+%d.%m.%Y.time.%H.%M.%S')
cd $1/Software
zip -r ${now}_output.zip $1/Software/output
