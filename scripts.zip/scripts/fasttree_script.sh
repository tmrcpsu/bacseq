#!/bin/bash

counter=0

for file in $1/Software/output/gff/*; do
	counter=$((counter+1))
	
	done 

if [[ $counter -gt 1 ]]
then
	echo "Passed"
now=$(date '+%d.%m.%Y.time.%H.%M.%S')

$1/Software/biotools/./FastTree -nt -gtr $1/Software/output/snp_sites/core_gene_alignment.aln.snp_sites.aln > $1/Software/output/FastTree/my_tree.newick

$1/Software/biotools/./FastTree -nt -gtr $1/Software/output/snp_sites/accessory_binary_genes_.fa.aln.snp_sites.aln > $1/Software/output/FastTree/my_tree_accessory_binary_gene.newick

cd $1/Software/output/FastTree/



python3 $1/Software/biotools/scripts/python_script/tree.py
python3 $1/Software/biotools/scripts/python_script/tree2.py

cd $1/Software/output/roary
python3 $1/Software/biotools/roary_plots/roary_plots.py $1/Software/output/FastTree/my_tree.newick $1/Software/output/roary/gene_presence_absence.csv
else
	echo "Your roary results not found. Skipping..." 
fi



bash $1/Software/biotools/scripts/html_script/create_index.sh "${1}" > $1/Software/output/results.html

cd $1/Software
# zip -r ${now}_output.zip $1/Software/output
