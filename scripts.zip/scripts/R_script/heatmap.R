
library("heatmaply")

#setfolder<-Sys.getenv("setwd")
#sett<-setfolder[1]
#setwd(sett)
qdir<-Sys.getenv("path_dir")
pathname<-qdir[1]
outdir<-Sys.getenv("output_name")
output_fol<-outdir[1]

df <- read.csv(file = pathname, sep="\t",stringsAsFactors = F,na.strings = '.',check.names=F)


df[is.na(df)] <- 0

df2 = df[1]
df[1] <- NULL

row.names(df) <- as.matrix(df2)
df[] <- lapply(df, function(x) as.numeric(gsub("\\;.*","", x)))

heatmaply(as.data.frame(df),
  seriate = "none",
  row_dend_left = F,
  plot_method = "plotly",
  column_text_angle = 90,
  colorbar_len = 0.5,
  col=viridis(100), 
  key=FALSE, 
  titleX = FALSE, 
  titleY = FALSE, 
  anim_duration=0,
  dendrogram = "none",
  file = output_fol
)


