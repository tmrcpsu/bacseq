#!/bin/bash


counter=0


for file in $1/Software/output/gff/*; do
	counter=$((counter+1))
	
	done 

if [[ $counter -gt 1 ]]
then
	echo "Passed"

snp-sites -mvp -o $1/Software/output/snp_sites/core_gene_alignment.aln $1/Software/output/roary/*.aln

snp-sites -mvp -o $1/Software/output/snp_sites/accessory_binary_genes_.fa.aln $1/Software/output/roary/accessory_binary_genes.fa
else
	echo "Your roary results not found. Skipping..." 
fi

