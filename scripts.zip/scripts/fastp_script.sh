#!/bin/bash
filename="$1/Software/output/file_log.txt"
file_long="$1/Software/output/file_long.txt"
if [ -s ${filename} ];then
while read p; do
	counter=$((counter+1))
	filename=$(basename -- "$p")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"

if [[ "$filename" == *"$R1_1"* ]] || [[ "$filename" == *"$R1_2"* ]] || [[ "$filename" == *"$R1_3"* ]];then
	R1_name=$p
fi
if [[ "$filename" == *"$R2_1"* ]] || [[ "$filename" == *"$R2_2"* ]] || [[ "$filename" == *"$R2_3"* ]];then
	R2_name=$p
fi

for file1 in $R1_name; do

file2=${file1/_1/_2}

echo $file1 $file2
mkdir $1/Software/output/fastp/${filename1}
cd $1/Software/output/fastp/${filename1}
fastp -i ${file1} -I ${file2} -o out_${filename1}_1.fastq.gz -O out_${filename1}_2.fastq.gz -w ${2} --html ${filename1}.html --json ${filename1}.json 

done

	done < ${filename}
fi

	#### Long reads
if [ -s ${file_long} ];then
	echo "Found long reads file."
while read long; do
	counter=$((counter+1))
	
	filename=$(basename -- "$long")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"


for file_l_read in $long; do



filename_long=$(basename -- "$file_l_read" .fq.gz)
long_path="${file_l_read%%.*}"
mkdir $1/Software/output/fastp/${filename1}
cd $1/Software/output/fastp/${filename1}
fastp -i ${file_l_read} -o out_${filename1}.fastq.gz -w ${2} --html ${filename1}.html --json ${filename1}.json 
fastp -i ${long_path}_1long.fq.gz -I ${long_path}_2long.fq.gz -o out_${filename1}_1.fastq.gz -O out_${filename1}_2.fastq.gz -w ${2} --html ${filename1}_12.html --json ${filename1}_12.json 

done

	done < ${file_long}

fi