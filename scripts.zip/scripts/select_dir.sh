#!/bin/bash

now=$(date '+%d.%m.%Y.time.%H.%M.%S')
result_file=$1/Software/output/results.html
fasta_check=$1/Software/output/Fasta/
if [[ -f "$result_file" || "$(ls -A $fasta_check)" ]]; then
	echo "Found old results file then removing directory."

	rm -r $1/Software/output/abricate/heatmap/*
	rm -r $1/Software/output/abricate/html_scaffolds/*
	rm -r $1/Software/output/abricate/scaffolds/*
	rm -r $1/Software/output/busco/graph_plot/*
	rm -r $1/Software/output/busco/scaffolds/*
	rm -r $1/Software/output/busco/visualization/*
	rm -r $1/Software/output/CRISPRCasFinder/*
	rm -r $1/Software/output/eggnog-mapper/*
	rm -r $1/Software/output/Fasta/contigs/*
	rm -r $1/Software/output/Fasta/scaffolds/*
	rm -r $1/Software/output/fastp/*
	rm -r $1/Software/output/FastQC/*
	rm -r $1/Software/output/FastTree/*
	rm -r $1/Software/output/gff/*
	rm -r $1/Software/output/MultiQC/*
	rm -r $1/Software/output/prokka/*
	rm -r $1/Software/output/quast/contigs/*
	rm -r $1/Software/output/quast/scaffolds/*
	rm -r $1/Software/output/run_dbcan/*
	rm -r $1/Software/output/snp_sites/*
	rm -r $1/Software/output/SPAdes/*
	rm -r $1/Software/output/staramr/contigs/*
	rm -r $1/Software/output/staramr/scaffolds/*


	rm -r $result_file
else
	echo "Result file not found. Do nothing."
fi
rm -r $1/Software/output/file_log.txt
rm -r $1/Software/output/file_long.txt
rm -r $1/Software/output/all_file_log.txt
rm -r $1/Software/output/file_log_R1.txt
rm -r $1/Software/output/file_log_R2.txt


for file1 in $3/*; do
	if [[ $file1 == *.gz ]]; then
	echo $file1 >> $1/Software/output/all_file_log.txt
elif [[ $file1 == *.fasta ]]; then
	echo $file1 >> $1/Software/output/all_file_log.txt
else
	echo "."
fi
	done

for file2 in $3/*_1*.gz; do
	if [[ ${file2} == *"long.fq.gz"* ]];then
		echo "Long reads found ${file2}"
	else
	echo $file2 >> $1/Software/output/file_log.txt
fi

	done

for file3 in $3/*_1*.gz; do

	echo $file3 >> $1/Software/output/file_log_R1.txt
	done

for file4 in $3/*_2*.gz; do

	echo $file4 >> $1/Software/output/file_log_R2.txt
	done

for file5 in $3/*.gz; do
	if [[ ${file5} != *"_1"* ]];then
		if [[ ${file5} != *"_2"* ]];then
	echo $file5 >> $1/Software/output/file_long.txt
fi
fi
done