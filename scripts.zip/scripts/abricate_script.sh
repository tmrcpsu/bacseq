#!/bin/bash

for file_scaffold in $1/Software/output/Fasta/scaffolds/*.fasta; do

	filename=$(basename -- "$file_scaffold" .scaffolds.fasta)
extension="${filename##*.}"
# filename="${filename%%.*}"
abricate --db ncbi --threads $2 --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_ncbi_scaffolds_output.tab
abricate --db card -threads $2 --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_card_scaffolds_output.tab
abricate --db resfinder -threads $2 --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_resfinder_scaffolds_output.tab
abricate --db argannot -threads $2 --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_argannot_scaffolds_output.tab
abricate --db megares -threads $2 --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_megares_scaffolds_output.tab
abricate --db plasmidfinder -threads $2 --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_plasmidfinder_scaffolds_output.tab
abricate --db vfdb -threads $2 --nopath --debug $file_scaffold > $1/Software/output/abricate/scaffolds/${filename}_vfdb_scaffolds_output.tab


	done

cd $1/Software/output/abricate/scaffolds/





ncbi_path="$1/Software/output/abricate/scaffolds/summary_ncbi.tsv"
abricate --summary *_ncbi_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_ncbi.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_ncbi.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${ncbi_path}" > $1/Software/output/abricate/html_scaffolds/Summary_ncbi.html


card_path="$1/Software/output/abricate/scaffolds/summary_card.tsv"
abricate --summary *_card_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_card.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_card.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${card_path}" > $1/Software/output/abricate/html_scaffolds/Summary_card.html

resfinder_path="$1/Software/output/abricate/scaffolds/summary_resfinder.tsv"
abricate --summary *_resfinder_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_resfinder.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_resfinder.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${resfinder_path}" > $1/Software/output/abricate/html_scaffolds/Summary_resfinder.html

argannot_path="$1/Software/output/abricate/scaffolds/summary_argannot.tsv"
abricate --summary *_argannot_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_argannot.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_argannot.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${argannot_path}" > $1/Software/output/abricate/html_scaffolds/Summary_argannot.html

megares_path="$1/Software/output/abricate/scaffolds/summary_megares.tsv"
abricate --summary *_megares_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_megares.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_megares.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${megares_path}" > $1/Software/output/abricate/html_scaffolds/Summary_megares.html

plasmidfinder_path="$1/Software/output/abricate/scaffolds/summary_plasmidfinder.tsv"
abricate --summary *_plasmidfinder_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_plasmidfinder.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_plasmidfinder.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${plasmidfinder_path}" > $1/Software/output/abricate/html_scaffolds/Summary_plasmidfinder.html

vfdb_path="$1/Software/output/abricate/scaffolds/summary_vfdb.tsv"
abricate --summary *_vfdb_scaffolds_output.tab > $1/Software/output/abricate/scaffolds/summary_vfdb.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary_vfdb.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${vfdb_path}" > $1/Software/output/abricate/html_scaffolds/Summary_vfdb.html

sum_path="$1/Software/output/abricate/scaffolds/summary.tsv"
abricate --summary *.tab > $1/Software/output/abricate/scaffolds/summary.tsv
awk -i inplace '{$0=gensub(/\s*\S+/,"",2)}1' summary.tsv
bash $1/Software/biotools/scripts/html_script/abricate_scaffolds_html_script.sh "${1}" "${sum_path}" > $1/Software/output/abricate/html_scaffolds/Summary.html

export path_dir=$ncbi_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_ncbi.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_ncbi_files/

export path_dir=$card_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_card.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_card_files/


export path_dir=$resfinder_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_resfinder.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_resfinder_files/

export path_dir=$argannot_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_argannot.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_argannot_files/

export path_dir=$megares_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_megares.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_megares_files/

export path_dir=$plasmidfinder_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_plasmidfinder.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_plasmidfinder_files/

export path_dir=$vfdb_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_vfdb.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_vfdb_files/

export path_dir=$sum_path
export output_name=$1/Software/output/abricate/heatmap/heatmap_summary.html
Rscript $1/Software/biotools/scripts/R_script/heatmap.R
rm -rf $1/Software/output/abricate/heatmap/heatmap_summary_files/

