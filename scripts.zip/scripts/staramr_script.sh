#!/bin/bash

contigs="contigs"
scaffolds="scaffolds"
cd $1/Software/output/staramr/
rm -rf scaffolds/
rm -rf contigs/ 
cd $1/Software/output/Fasta/scaffolds
staramr search -o $1/Software/output/staramr/scaffolds/ -n ${2} *.fasta
cd $1/Software/output/staramr/scaffolds/
sed -i 's/^\t/NA\t/;s/\t$/\tNA/;:0 s/\t\t/\tNA\t/;t0' detailed_summary.tsv 

	bash $1/Software/biotools/scripts/html_script/staramr_html_script.sh "${1}" "${scaffolds}" > $1/Software/output/staramr/scaffolds/staramr_scaffolds.html
	bash $1/Software/biotools/scripts/html_script/staramr_html_mlst_script.sh "${1}" "${scaffolds}" > $1/Software/output/staramr/scaffolds/staramr_mlst_scaffolds.html
	bash $1/Software/biotools/scripts/html_script/staramr_html_resfinder_script.sh "${1}" "${scaffolds}" > $1/Software/output/staramr/scaffolds/staramr_resfinder_scaffolds.html



if [ -z "$(ls -A $1/Software/output/Fasta/contigs)" ]; then
	echo "Not found contigs files skipping..."
else
cd $1/Software/output/Fasta/contigs
staramr search -o $1/Software/output/staramr/contigs/ -n ${2} *.fasta
cd $1/Software/output/staramr/contigs/
sed -i 's/^\t/NA\t/;s/\t$/\tNA/;:0 s/\t\t/\tNA\t/;t0' detailed_summary.tsv 
		bash $1/Software/biotools/scripts/html_script/staramr_html_script.sh "${1}" "${contigs}" > $1/Software/output/staramr/contigs/staramr_contigs.html
		bash $1/Software/biotools/scripts/html_script/staramr_html_mlst_script.sh "${1}" "${contigs}" > $1/Software/output/staramr/contigs/staramr_mlst_contigs.html
		bash $1/Software/biotools/scripts/html_script/staramr_html_resfinder_script.sh "${1}" "${contigs}" > $1/Software/output/staramr/contigs/staramr_resfinder_contigs.html
fi