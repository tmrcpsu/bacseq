#!/bin/bash

for file_scaffold in $1/Software/output/Fasta/scaffolds/*.fasta; do
	file_cut=$(basename -- "$file_scaffold" .fasta)

#comments.when.some.file.name.missing
# filename=$(basename -- "$file_faa" faa)
# extension="${filename##*.}"
# filename="${filename%%.*}"
# file_cut="${filename%_*}"
cd $1/Software/output/busco/scaffolds/
busco -i $file_scaffold --out_path $1/Software/output/busco/scaffolds -o $file_cut -l bacteria_odb10 -f -c ${2} -m ${3} 

#Prepare data for generate plot
cp $1/Software/output/busco/scaffolds/${file_cut}/short_summary.specific.bacteria_odb10.${file_cut}.txt $1/Software/output/busco/graph_plot/short_summary.specific.bacteria_odb10.${file_cut}.txt

#Create Web
cd $1/Software/output/busco/scaffolds/${file_cut}/run_bacteria_odb10/
sed '1,2d' full_table.tsv > ${file_cut}_full_table.tsv
bash $1/Software/biotools/scripts/html_script/busco_html_script.sh "${1}" "${file_cut}" > $1/Software/output/busco/visualization/${file_cut}.html
	done


#Generate plot
generate_plot.py -wd $1/Software/output/busco/graph_plot

