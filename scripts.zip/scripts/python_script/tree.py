#!/usr/bin/env python
from ete3 import Tree


t = Tree("my_tree.newick")
print(t)
t.render('my_tree.png')


