#!/usr/bin/env python
from ete3 import Tree


ac_binary_gene = Tree("my_tree_accessory_binary_gene.newick")
print(ac_binary_gene)
ac_binary_gene.render('accessory_binary_gene.png')
