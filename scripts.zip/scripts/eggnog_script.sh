#!/bin/bash


for file_faa in $1/Software/output/prokka/*/*.faa; do

	file_cut=$(basename -- "$file_faa" .faa)

#comments.when.some.file.name.missing
# filename1=$(basename -- "$file_scaffold")
# extension="${filename##*.}"
# filename="${filename%%.*}"
# filename1="${filename%_*}"
echo "Eggnog-Mapper are running for ${file_cut}..."
mkdir $1/Software/output/eggnog-mapper/${file_cut}
cd $1/Software/output/eggnog-mapper/${file_cut}
emapper.py --data_dir $1/Software/biotools/eggnog-mapper/data -i ${file_faa} --output_dir $1/Software/output/eggnog-mapper/${file_cut} -o ${file_cut} --override --evalue ${3} --score ${4} --pident ${5} --query_cover ${6} --subject_cover ${7} --itype proteins --tax_scope auto --target_orthologs all --go_evidence non-electronic --pfam_realign none --report_orthologs --decorate_gff yes --cpu ${2} --excel 
sed -i '1,4d' ${file_cut}.emapper.annotations
head -n -3 ${file_cut}.emapper.annotations  > ${file_cut}.emapper.tsv 

bash $1/Software/biotools/scripts/html_script/emapper_html_script.sh "${1}" "${file_cut}" > $1/Software/output/eggnog-mapper/${file_cut}/${file_cut}.html

	done