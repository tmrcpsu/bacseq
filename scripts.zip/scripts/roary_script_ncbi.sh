#!/bin/bash
rm -rf $1/Software/output/roary/
counter=0
filename="$1/Software/output/file_log.txt"
species_name=$5
APPEND="##FASTA"
cd $1/Software/output/gff
mkdir $1/Software/output/ncbi_gff
cd $1/Software/output/ncbi_gff
ncbi-genome-download -s refseq --format fasta,gff -o $1/Software/output/ncbi_gff -l complete --flat-output --progress-bar -p 16 --verbose --genera "${species_name}" bacteria


for file_gff in $1/Software/output/ncbi_gff/*.gff.gz; do
	filename_fna=$(basename $file_gff .gff.gz)
	gzip -d ${file_gff}
	gzip -d ${filename_fna}.fna.gz
	echo "$APPEND" >> ${filename_fna}.gff
	cat ${filename_fna}.gff ${filename_fna}.fna > ${filename_fna}_concat.gff
	rm -f ${filename_fna}.gff 
	rm -f ${filename_fna}.fna 

	
	done 

mv $1/Software/output/ncbi_gff/* $1/Software/output/gff
rm -rf $1/Software/output/ncbi_gff
for file in $1/Software/output/gff/*; do
	counter=$((counter+1))
	
	done 

if [[ $counter -gt 1 ]]
then
	echo "Passed"
cd $1/Software/output/gff
	roary ${3} ${4} -p ${2} -f $1/Software/output/roary/ -v *.gff
	
	cd $1/Software/output/roary/
	sed 's/\("\([^"]*\)"\)\?,/\2\t/g' gene_presence_absence.csv > gene_presence_absence_convert.tsv
	sed -i 's/\"//g' gene_presence_absence_convert.tsv
	sed -i 's/^\t/NA\t/;s/\t$/\tNA/;:0 s/\t\t/\tNA\t/;t0' gene_presence_absence_convert.tsv

	bash $1/Software/biotools/scripts/html_script/roary_html_script.sh "${1}" "${counter}" > $1/Software/output/roary/gene_presence_absence_convert.html

	cd $1/Software/output/roary
python3 $1/Software/biotools/roary_plots/roary_plots.py $1/Software/output/roary/accessory_binary_genes.fa.newick $1/Software/output/roary/gene_presence_absence.csv

else
	echo "Your GFF files must use at least 2 files" 
fi

