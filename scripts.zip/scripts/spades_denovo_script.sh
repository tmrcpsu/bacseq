#!/bin/bash

filename="$1/Software/output/file_log.txt"
file_long="$1/Software/output/file_long.txt"
R1_1="_1"
R2_1="_2"
R1_2="R1"
R2_2="R2"
R1_3="001"
R2_3="002"
counter=0
assembler_option=$6
if [ -s ${filename} ];then
	echo "Short read not found."
if [[ "$assembler_option" == "SPAdes" ]]; then
	echo "SPAdes assembling..."
while read p; do
	counter=$((counter+1))
	
	filename=$(basename -- "$p")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"


for file1 in $p; do

file2=${file1/_1/_2}

echo $file1 $file2
python3 $1/Software/biotools/SPAdes/bin/spades.py --cov-cutoff $2 -t $3 -o $1/Software/output/SPAdes/${filename1} -1 ${file1} -2 ${file2} $4  $5 -m 1000
cp $1/Software/output/SPAdes/${filename1}/scaffolds.fasta $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta
cp $1/Software/output/SPAdes/${filename1}/contigs.fasta $1/Software/output/SPAdes/${filename1}/${filename1}.contigs.fasta
cd $1/Software/output/
cp $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta $1/Software/output/Fasta/scaffolds
cp $1/Software/output/SPAdes/${filename1}/${filename1}.contigs.fasta $1/Software/output/Fasta/contigs

done

	done < ${filename}

elif [[ "$assembler_option" == "Unicycler" ]]; then 

	echo "Unicycler assembling..."

while read p; do
	counter=$((counter+1))
	
	filename=$(basename -- "$p")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"


for file1 in $p; do

file2=${file1/_1/_2}

echo $file1 $file2
unicycler --min_fasta_length ${2} -t ${3} -o $1/Software/output/SPAdes/${filename1} -1 ${file1} -2 ${file2} 
cp $1/Software/output/SPAdes/${filename1}/assembly.fasta $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta
cd $1/Software/output/
cp $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta $1/Software/output/Fasta/scaffolds

done

	done < ${filename}



fi
fi
#### Long reads
if [ -s ${file_long} ];then
	echo "Found long reads file."
	echo "Unicycler assembling..."

while read long; do
	counter=$((counter+1))
	
	filename=$(basename -- "$long")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"


for file_l_read in $long; do

filename_long=$(basename -- "$file_l_read" .fq.gz)
long_path="${file_l_read%%.*}"

unicycler --min_fasta_length 150 -1 ${long_path}_1long.fq.gz -2 ${long_path}_2long.fq.gz -l ${file_l_read} -t ${3} -o $1/Software/output/SPAdes/${filename1}

# unicycler --min_fasta_length 150 -t ${3} -o $1/Software/output/SPAdes/${filename1} -l ${file_l_read}
cp $1/Software/output/SPAdes/${filename1}/assembly.fasta $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta
cd $1/Software/output/
cp $1/Software/output/SPAdes/${filename1}/${filename1}.scaffolds.fasta $1/Software/output/Fasta/scaffolds

done

	done < ${file_long}




else
	echo "Long reads file not found. Skipping..."
fi