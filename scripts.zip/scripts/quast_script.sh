#!/bin/bash

op_contigs=$1/Software/output/quast/contigs
op_scaffolds=$1/Software/output/quast/scaffolds
cd $1/Software/output/Fasta/scaffolds/

	
	
quast *.fasta -o ${op_scaffolds}/ --threads ${2}		


if [ -z "$(ls -A $1/Software/output/Fasta/contigs)" ]; then
	echo "Not found contigs files skipping..."
else
cd $1/Software/output/Fasta/contigs/
quast *.fasta -o ${op_contigs}/ --threads ${2}
fi