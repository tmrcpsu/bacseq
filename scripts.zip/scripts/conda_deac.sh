#!/bin/bash
conda init bash

conda deactivate
