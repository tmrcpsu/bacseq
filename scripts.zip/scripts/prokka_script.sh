#!/bin/bash
filename="$1/Software/output/file_log.txt"
counter=0
compliant=$8
addgenes=$9
usegenus=${10}
rfam=${11}

for file_scaffold in $1/Software/output/Fasta/scaffolds/*.fasta; do

	filename1=$(basename -- "$file_scaffold" .fasta)

#comments.when.some.file.name.missing
# filename1=$(basename -- "$file_scaffold")
# extension="${filename##*.}"
# filename="${filename%%.*}"
# filename1="${filename%_*}"
	prokka --outdir $1/Software/output/prokka/${filename1} --force $compliant --centre $2 --prefix ${filename1} $addgenes --genus $3 --species $4 \
	--strain ${filename1} --kingdom $5 --gcode $6 $usegenus $rfam --cpus $7 $file_scaffold
cp $1/Software/output/prokka/${filename1}/${filename1}.gff $1/Software/output/gff

cd $1/Software/output/prokka/${filename1} 
sed 's/^\t/NA\t/;s/\t$/\tNA/;:0 s/\t\t/\tNA\t/;t0' ${filename1}.tsv >  ${filename1}_edited.tsv

bash $1/Software/biotools/scripts/html_script/prokka_html_script.sh "${1}" "${filename1}" > $1/Software/output/prokka/${filename1}/${filename1}.html


	done

bash $1/Software/biotools/scripts/html_script/prokka_chart.sh "${1}" > $1/Software/output/prokka/prokka_chart.html	

bash $1/Software/biotools/scripts/html_script/prokka_summary.sh "${1}" > $1/Software/output/prokka/prokka_summary.html	