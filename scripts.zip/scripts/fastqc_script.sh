#!/bin/bash



filename="$1/Software/output/all_file_log.txt"


while read p; do
	counter=$((counter+1))

	filename=$(basename -- "$p")
extension="${filename##*.}"
filename="${filename%%.*}"
filename1="${filename%_*}"


if [ -d "$1/Software/output/FastQC/${filename1}" ] 
then
    echo "Directory $1/Software/output/FastQC/${filename1} exists." 
else

    echo "Directory $1/Software/output/FastQC/${filename1} does not exists, Creating Directory..."
    mkdir $1/Software/output/FastQC/${filename1}
fi

$1/Software/biotools/FastQC/./fastqc -t ${2} $p --outdir=$1/Software/output/FastQC/${filename1}


	done < $filename