#!/bin/bash


for file_faa in $1/Software/output/prokka/*/*.faa; do

	file_cut=$(basename -- "$file_faa" .faa)

#comments.when.some.file.name.missing
# filename=$(basename -- "$file_faa" faa)
# extension="${filename##*.}"
# filename="${filename%%.*}"
# file_cut="${filename%_*}"
tools_string=${6}
tools_string=$(eval echo $tools_string)
echo "run_dbcan are running for ${file_cut}..."
echo ${file_faa}
run_dbcan ${file_faa} protein --out_dir $1/Software/output/run_dbcan/${file_cut} --db_dir $1/Software/biotools/dbcan_db --dia_cpu ${2} --hmm_cpu ${2} --dia_eval ${3} --hmm_eval ${4} --hmm_cov ${5} -t ${tools_string}
cd $1/Software/output/run_dbcan/${file_cut}
cp overview.txt overview.tsv
rm -r $1/home
bash $1/Software/biotools/scripts/html_script/rundbcan_html_script.sh "${1}" "${file_cut}" > $1/Software/output/run_dbcan/${file_cut}/${file_cut}.html
	done


