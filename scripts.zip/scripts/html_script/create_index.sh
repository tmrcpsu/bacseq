#!/bin/bash
var=${1}
for fastqc_file in ${var}/Software/output/FastQC/*/*.html;
do

fastqc_filename=$(basename $fastqc_file .html)
#fastqc_array=()
fastqc_array+=("${fastqc_filename[@]}")
fastqc_file2+=("${fastqc_file[@]}")

done

#echo "${fastqc_array[2]}"}

for multiqc_file in ${var}/Software/output/MultiQC/*;
do

multiqc_filename=$(basename $multiqc_file .html)
multiqc_array+=("${multiqc_file[@]}")

multiqc_file2="${multiqc_file%"${multiqc_file##*[!/]}"}"
multiqc_file2="${multiqc_file2##*/}"
#echo $multiqc_file2
#echo $multiqc_file
multiqc_file3+=("${multiqc_file2[@]}")
done

#echo "${multiqc_file3[@]}"

for fastp_file in ${var}/Software/output/fastp/*;
do

fastp_filename=$(basename $fastp_file .html)
fastp_array+=("${fastp_file[@]}")
fastp_file2="${fastp_file%"${fastp_file##*[!/]}"}"
fastp_file2="${fastp_file2##*/}"

fastp_file3+=("${fastp_file2[@]}")
#echo $fastp_file
done


for spades_file in ${var}/Software/output/SPAdes/*/*.scaffolds.fasta;
do

spades_filename=$(basename $spades_file .scaffolds.fasta)
spades_array+=("${spades_file[@]}")
spades_file2="${spades_file%"${spades_file##*[!/]}"}"
spades_file2="${spades_file2##*/}"

spades_file3+=("${spades_filename[@]}")
#echo $fastp_file
done


#echo "${fastp_file3[@]}"

for quast_file in ${var}/Software/output/quast/contigs/*;
do

quast_filename=$(basename $quast_file .html)
quast_array+=("${quast_file[@]}")
quast_file2="${quast_file%"${quast_file##*[!/]}"}"
quast_file2="${quast_file2##*/}"

quast_file3+=("${quast_file2[@]}")
#echo $fastp_file
done

for busco_file in ${var}/Software/output/busco/visualization/*.html;
do

busco_filename=$(basename "$busco_file" .scaffolds.html)
busco_array+=("${busco_file[@]}")
busco_filename2+=("${busco_filename[@]}")
done

for prokka_file in ${var}/Software/output/prokka/*/*.html;
do

prokka_filename=$(basename "$prokka_file" .html)
prokka_array+=("${prokka_file[@]}")
prokka_filename2+=("${prokka_filename[@]}")
done

for eggnog_file in ${var}/Software/output/eggnog-mapper/*/*.html;
do

eggnog_filename=$(basename "$eggnog_file" .scaffolds.html)
eggnog_array+=("${eggnog_file[@]}")
eggnog_filename2+=("${eggnog_filename[@]}")
done


for staramr_file in ${var}/Software/output/staramr/contigs/*/*.html;
do

staramr_filename=$(basename "$staramr_file" .html)
staramr_array+=("${staramr_file[@]}")
staramr_filename2+=("${staramr_filename[@]}")
done

for rundbcan_file in ${var}/Software/output/run_dbcan/*/*.html;
do

rundbcan_filename=$(basename "$rundbcan_file" .scaffolds.html)
rundbcan_array+=("${rundbcan_file[@]}")
rundbcan_filename2+=("${rundbcan_filename[@]}")
done

for crisprcasfinder_file in ${var}/Software/output/CRISPRCasFinder/*;
do

crisprcasfinder_filename=$(basename "$crisprcasfinder_file" .html)
crisprcasfinder_array+=("${crisprcasfinder_file[@]}")
crisprcasfinder_file2="${crisprcasfinder_file%"${crisprcasfinder_file##*[!/]}"}"
crisprcasfinder_file2="${crisprcasfinder_file2##*/}"

crisprcasfinder_file3+=("${crisprcasfinder_file2[@]}")
done
echo "<!DOCTYPE html>"
    echo "<html>"
    echo "<head>"
    echo "<meta charset=\"utf-8\">"
    echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">"
    echo "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css\" integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">"
    echo "<title>Result</title>"
   
    echo "<script src=\"https://code.jquery.com/jquery-3.5.1.js\"></script>"

 echo "<style>"
 echo "body, html"
      echo "{"
      echo "margin: 0; 
      padding: 0; 
      height: 100%; 
      width: 100%; 
      overflow: hidden;"
           echo "}"
echo "#container2 {"
echo "width: 100vh;"
echo "height: 100vh;"
echo "position: relative;"
echo "margin:0 auto;"
echo "line-height: 1.4em;"
echo "}"
echo ".dropdown-submenu {
  position: relative;
}

.dropdown-submenu a::after {
  transform: rotate(-90deg);
  position: absolute;
  right: 6px;
  top: .8em;
}

.dropdown-submenu .dropdown-menu {
  top: 0;
  left: 100%;
  margin-left: .1rem;
  margin-right: .1rem;
}"
 echo "iframe"
      echo "{"
      echo "width: 100%; height: 100vh; max-width: 100%;"
           echo "}"
 echo "@media only screen and (max-width: 479px){"
    echo "#container2 { width: 90%; height: 90%;}"
echo "}"
echo "</style>"

    echo "</head>"
    echo "<body>"
    echo "<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">"
   echo "<a class=\"navbar-brand\" href=\"#\">BacSeq Results</a>"
 echo "<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">"
   echo "<span class=\"navbar-toggler-icon\"></span>"
 echo "</button>"

 echo "<div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">"
  echo  "<ul class=\"navbar-nav mr-auto\>"
  
   echo  "<li class=\"nav-item dropdown\">
                <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdownMenuLink\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                Quality Control</a>
                <ul class=\"dropdown-menu\" aria-labelledby=\"navbarDropdownMenuLink\">
                    <li class=\"dropdown-submenu\">
                        <a href=\"#\" class=\"dropdown-toggle dropdown-item\">FastQC</a>
                        <ul class=\"dropdown-menu\">
                            <li class=\"dropdown-item\">"
                              for fastqc in "${fastqc_array[@]}"
do
   : 
   fastqc_removestr=${fastqc%%_*}
    echo  "<li class=\"dropdown-item\">"
  echo "<a class=\"dropdown-item\" href=\"FastQC/${fastqc_removestr}/${fastqc}.html\" target=\"search_iframe\">${fastqc}</a>"
    echo      "</li>"
done
                           
          echo              "</ul>
                         
                    </li>
                    <li class=\"dropdown-submenu\">
                        <a href=\"#\" class=\"dropdown-toggle dropdown-item\">MultiQC</a>
                        <ul class=\"dropdown-menu\">
                            <li class=\"dropdown-item\">"
                            
   echo  "<li class=\"dropdown-item\">"
  echo "<a class=\"dropdown-item\" href=\"MultiQC/multiqc_report.html\" target=\"search_iframe\">MultiQC</a>"
 echo      "</li>"

                           
          echo              "</ul>
                              <li class=\"dropdown-submenu\">
                        <a href=\"#\" class=\"dropdown-toggle dropdown-item\">Fastp</a>
                        <ul class=\"dropdown-menu\">
                            <li class=\"dropdown-item\">"
                                 for fastp in "${fastp_file3[@]}"
do
   : 
   fastp_removestr=${fastp_file3%%_*}
   echo  "<li class=\"dropdown-item\">"
  echo "<a class=\"dropdown-item\" href=\"fastp/${fastp}/${fastp}.html\" target=\"search_iframe\">${fastp}</a>"
echo      "</li>"
done
                            
  echo                      "</ul>
                    </li>
                </ul>
            </li>"

echo  "<li class=\"nav-item dropdown\">
                <a href=\"#\" id=\"menu\" 
                    data-toggle=\"dropdown\" class=\"nav-link dropdown-toggle\"
                    data-display=\"static\">Assembly Results</a>
                <ul class=\"dropdown-menu\">
                    <li class=\"dropdown-submenu\">
                        <a href=\"#\" class=\"dropdown-toggle dropdown-item\">Contigs</a>
                        <ul class=\"dropdown-menu\">
                            <li class=\"dropdown-item\">"
                              for spades_contigs in "${spades_file3[@]}"
do
   : 
    echo  "<li class=\"dropdown-item\">"
  echo "<a class=\"dropdown-item\" href=\"SPAdes/${spades_contigs}/${spades_contigs}.contigs.fasta\" target=\"search_iframe\">${spades_contigs}</a>"
    echo      "</li>"
done
                           
          echo              "</ul>
                         
                    </li>
                    <li class=\"dropdown-submenu\">
                        <a href=\"#\" class=\"dropdown-toggle dropdown-item\">Scaffolds</a>
                        <ul class=\"dropdown-menu\">"
                            for spades_scaffolds in "${spades_file3[@]}"
do
   : 
   echo  "<li class=\"dropdown-item\">"
  echo "<a class=\"dropdown-item\" href=\"SPAdes/${spades_scaffolds}/${spades_scaffolds}.scaffolds.fasta\" target=\"search_iframe\">${spades_scaffolds}</a>"
 echo      "</li>"
done
                           
          echo              "</ul>
                              <li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Assembly Graph</a>
                        <ul class=\"dropdown-menu\">
                          "
                          for spades_graph in "${spades_file3[@]}"
do
   : 
  echo "<li class=\"dropdown-submenu\">"
   echo "<a class=\"dropdown-item dropdown-toggle\" href=\"#\">${spades_graph}</a>"
   echo "<ul class=\"dropdown-menu\">"
  
   echo  "<li><a class=\"dropdown-item\" href=\"SPAdes/${spades_graph}/assembly_graph.fastg\" target=\"search_iframe\">Assembly graph</a></li>"
   echo  "<li><a class=\"dropdown-item\" href=\"SPAdes/${spades_graph}/assembly_graph_after_simplification.gfa\" target=\"search_iframe\">Assembly graph after simplification</a></li>"
   echo  "<li><a class=\"dropdown-item\" href=\"SPAdes/${spades_graph}/assembly_graph_with_scaffolds.gfa\" target=\"search_iframe\">Assembly graph with scaffolds</a></li>"
echo "</ul>"
echo "</li>"
done

      echo             " </li>
                </ul>
            </li>
            </ul>"

   
    
    echo  "<li class=\"nav-item dropdown\">
                <a href=\"#\" id=\"menu\" 
                    data-toggle=\"dropdown\" class=\"nav-link dropdown-toggle\"
                    data-display=\"static\">Assembly Quality Assessment</a>
                <ul class=\"dropdown-menu\">
                    <li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Quality Assessment</a>
                       
                        <ul class=\"dropdown-menu\">"
 
   echo "<li><a class=\"dropdown-item\" href=\"quast/contigs/report.html\" target=\"search_iframe\">Contigs</a></li>"
   echo "<li><a class=\"dropdown-item\" href=\"quast/scaffolds/report.html\" target=\"search_iframe\">Scaffolds</a></li>"
   
echo "</ul>"
  echo "</li>"
                   echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Completeness Assessment</a>
            <ul class=\"dropdown-menu\">"
               echo "<li><a class=\"dropdown-item\" href=\"busco/graph_plot/busco_figure.png\" target=\"search_iframe\">Overview</a></li>"
               echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Detail</a>
                        <ul class=\"dropdown-menu\">
                          "
                          for busco in "${busco_filename2[@]}"
do
   : 
  echo "<li>"
  echo "<a class=\"dropdown-item\" href=\"busco/visualization/${busco}.scaffolds.html\" target=\"search_iframe\">${busco}</a>"
   
 echo "</li>"
 
done
   echo  "</ul>"
  echo "</li>"
  echo  "</ul>"
echo  "</ul>"
    echo  "<li class=\"nav-item dropdown\">
                <a href=\"#\" id=\"menu\" 
                    data-toggle=\"dropdown\" class=\"nav-link dropdown-toggle\"
                    data-display=\"static\">Annotation</a>
                <ul class=\"dropdown-menu\">
                    <li class=\"dropdown-submenu\"><a class=\"dropdown-item\" href=\"prokka/prokka_summary.html\" target=\"search_iframe\">Summary</a>"
                       
                       
  echo "</li>"
                   echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Detail</a>
            <ul class=\"dropdown-menu\">"
               for prokka in "${prokka_filename2[@]}"
do
   : 
   prokka_removestr=${prokka_filename2%%_*}
  echo "<li><a class=\"dropdown-item\" href=\"prokka/${prokka}/${prokka}.html\" target=\"search_iframe\">${prokka}</a></li>"
done
echo "</li>"
  echo "</ul>"
      echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">EggNOG</a>"
      echo "<ul class=\"dropdown-menu\">"
      eggnog_path=${var}/Software/biotools/eggnog-mapper/data
 if [ -d "${eggnog_path}" ];
 then
  
     for eggnog in "${eggnog_filename2[@]}"
do
   : 
   echo  "<li>"
   eggnog_removestr=${eggnog_filename2%%_*}
  echo "<a class=\"dropdown-item\" href=\"eggnog-mapper/${eggnog}.scaffolds/${eggnog}.scaffolds.html\" target=\"search_iframe\">${eggnog}</a></li>"
done
else
  echo  "<li>"
    echo    "<a class=\"dropdown-item\" href=\"${var}/Software/biotools/scripts/html_script/eggnog_notfound.html\"  target=\"search_iframe\"  aria-expanded=\"false\">"
    echo      "EggNOG didn't install"
     echo   "</a>"
 
fi
echo "</li>"
      echo "</ul>"
     
  echo  "</ul>"


echo  "<li class=\"nav-item dropdown\">
                <a href=\"#\" id=\"menu\" 
                    data-toggle=\"dropdown\" class=\"nav-link dropdown-toggle\"
                    data-display=\"static\">Antibiotic Resistance</a>
                <ul class=\"dropdown-menu\">"
                  
                   echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Summary</a>
            <ul class=\"dropdown-menu\">"
             
   echo "<li><a class=\"dropdown-item\" href=\"abricate/heatmap/heatmap_summary.html\" target=\"search_iframe\">Summary</a></li>"
   echo "<li><a class=\"dropdown-item\" href=\"abricate/heatmap/heatmap_ncbi.html\" target=\"search_iframe\">NCBI</a></li>"
      echo "<li><a class=\"dropdown-item\" href=\"abricate/heatmap/heatmap_card.html\" target=\"search_iframe\">Card</a></li>"
      echo "<li><a class=\"dropdown-item\" href=\"abricate/heatmap/heatmap_resfinder.html\" target=\"search_iframe\">Resfinder</a></li>"
echo "<li><a class=\"dropdown-item\" href=\"abricate/heatmap/heatmap_argannot.html\" target=\"search_iframe\">ARG-ANNOT</a></li>"
   echo "<li><a class=\"dropdown-item\" href=\"abricate/heatmap/heatmap_megares.html\" target=\"search_iframe\">MEGARes</a></li>"
      echo "<li><a class=\"dropdown-item\" href=\"abricate/heatmap/heatmap_plasmidfinder.html\" target=\"search_iframe\">Plasmidfinder</a></li>"
         echo "<li><a class=\"dropdown-item\" href=\"abricate/heatmap/heatmap_vfdb.html\" target=\"search_iframe\">VFDB</a></li>"

  echo "</ul>"
  echo "</li>"
       echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Detail</a>
            <ul class=\"dropdown-menu\">"
             
   echo "<li><a class=\"dropdown-item\" href=\"abricate/html_scaffolds/Summary.html\" target=\"search_iframe\">Summary</a></li>"
    echo "<li><a class=\"dropdown-item\" href=\"abricate/html_scaffolds/Summary_ncbi.html\" target=\"search_iframe\">NCBI</a></li>"
     echo "<li><a class=\"dropdown-item\" href=\"abricate/html_scaffolds/Summary_card.html\" target=\"search_iframe\">Card</a></li>"
      echo "<li><a class=\"dropdown-item\" href=\"abricate/html_scaffolds/Summary_resfinder.html\" target=\"search_iframe\">Resfinder</a></li>"
       echo "<li><a class=\"dropdown-item\" href=\"abricate/html_scaffolds/Summary_argannot.html\" target=\"search_iframe\">ARG-ANNOT</a></li>"
        echo "<li><a class=\"dropdown-item\" href=\"abricate/html_scaffolds/Summary_megares.html\" target=\"search_iframe\">MEGARes</a></li>"
         echo "<li><a class=\"dropdown-item\" href=\"abricate/html_scaffolds/Summary_plasmidfinder.html\" target=\"search_iframe\">Plasmidfinder</a></li>"
          echo "<li><a class=\"dropdown-item\" href=\"abricate/html_scaffolds/Summary_vfdb.html\" target=\"search_iframe\">VFDB</a></li>"

  echo "</ul>"
    echo "</li>"
     echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">StarAMR</a>
            <ul class=\"dropdown-menu\">"
               echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Contigs</a>
                        <ul class=\"dropdown-menu\">"
  echo "<li><a class=\"dropdown-item\" href=\"staramr/contigs/staramr_contigs.html\" target=\"search_iframe\">Summary</a></li>"
  echo "<li><a class=\"dropdown-item\" href=\"staramr/contigs/staramr_mlst_contigs.html\" target=\"search_iframe\">Mlst</a></li>"
echo "<li><a class=\"dropdown-item\" href=\"staramr/contigs/staramr_resfinder_contigs.html\" target=\"search_iframe\">Resfinder</a></li>"

    echo "</li>"
echo "</ul>"  

echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Scaffolds</a>
                        <ul class=\"dropdown-menu\">"
  echo "<li><a class=\"dropdown-item\" href=\"staramr/scaffolds/staramr_scaffolds.html\" target=\"search_iframe\">Summary</a></li>"
echo "<li><a class=\"dropdown-item\" href=\"staramr/scaffolds/staramr_mlst_scaffolds.html\" target=\"search_iframe\">Mlst</a></li>"
echo "<li><a class=\"dropdown-item\" href=\"staramr/scaffolds/staramr_resfinder_scaffolds.html\" target=\"search_iframe\">Resfinder</a></li>"


   echo  "</ul>"
  echo "</li>"
  echo  "</ul>"
echo  "</ul>"

    
 echo  "<li class=\"nav-item dropdown\">
                <a href=\"#\" id=\"menu\" 
                    data-toggle=\"dropdown\" class=\"nav-link dropdown-toggle\"
                    data-display=\"static\">Comparative Analysis</a>
                <ul class=\"dropdown-menu\">"
                   echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Pan-genome</a>
            <ul class=\"dropdown-menu\">"
              
  echo "<li><a class=\"dropdown-item\" href=\"roary/gene_presence_absence_convert.html\" target=\"search_iframe\">Detail</a></li>"
     echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\" target=\"search_iframe\">Picture</a>"
     echo "<ul class=\"dropdown-menu\">"
echo "<li><a class=\"dropdown-item\" href=\"roary/pangenome_frequency.png\" target=\"search_iframe\">Frequency</a></li>"
echo "<li><a class=\"dropdown-item\" href=\"roary/pangenome_matrix.png\" target=\"search_iframe\">Matrix</a></li>"
echo "<li><a class=\"dropdown-item\" href=\"roary/pangenome_pie.png\" target=\"search_iframe\">Pie</a></li>"
     echo "</ul>"
     echo "</li>"

echo "</li>"
  echo "</ul>"
      echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">Phylogenetic tree</a>"
      echo "<ul class=\"dropdown-menu\">"
     echo "<li><a class=\"dropdown-item\" href=\"FastTree/my_tree.png\" target=\"search_iframe\">Summary</a></li>"
     echo "<li><a class=\"dropdown-item\" href=\"FastTree/accessory_binary_gene.png\" target=\"search_iframe\">Accessory Binary Gene</a></li>"
echo "</li>"
      echo "</ul>"
      
  echo  "</ul>"


echo  "<li class=\"nav-item dropdown\">
                <a href=\"#\" id=\"menu\" 
                    data-toggle=\"dropdown\" class=\"nav-link dropdown-toggle\"
                    data-display=\"static\">Other Analysis</a>
                <ul class=\"dropdown-menu\">"
                      echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">CAZyme annotation</a>"
      echo "<ul class="dropdown-menu">"
       for rundbcan in "${rundbcan_filename2[@]}"
do
   : 
   rundbcan_removestr=${rundbcan_filename2%%_*}
  echo "<li><a class=\"dropdown-item\" href=\"run_dbcan/${rundbcan}.scaffolds/${rundbcan}.scaffolds.html\" target=\"search_iframe\">${rundbcan}</a></li>"
done
 echo "</ul>"
      echo "</li>"
      echo "<li class=\"dropdown-submenu\"><a class=\"dropdown-item dropdown-toggle\" href=\"#\">CRISPR</a>"
      echo "<ul class="dropdown-menu">"
      for crisprcasfinder in "${crisprcasfinder_file3[@]}"
do
   : 
  crisprcasfinder_removestr=${crisprcasfinder_file3%%_*}
  echo "<li><a class=\"dropdown-item\" href=\"CRISPRCasFinder/${crisprcasfinder}/Visualization/index.html\" target=\"search_iframe\">${crisprcasfinder}</a></li>"
done
 echo "</ul>"
      echo "</li>"
  echo  "</ul>"

     
 echo "</div>"
echo "</nav>"
#echo "<iframe src=\"\#\" width=\"100%\" height=\"100%\" name=\"search_iframe\"></iframe>"
#echo "<div class=\"card\">"
echo "<div class=\"h_iframe\">"
   echo "<iframe src=\"${var}/Software/biotools/scripts/html_script/welcome.html\" frameborder=\"0\" name=\"search_iframe\" allowfullscreen></iframe>"
 echo  "</div>"
#echo "</div>"
echo "<script>"
echo "\$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
  if (!\$(this).next().hasClass('show')) {
    \$(this).parents('.dropdown-menu').first().find('.show').removeClass(\"show\");
  }
  var \$subMenu = \$(this).next(\".dropdown-menu\");
  \$subMenu.toggleClass('show');


  \$(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
    \$('.dropdown-submenu .show').removeClass(\"show\");
  });


  return false;
});"
echo "</script>"
   echo "<script src=\"https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js\" integrity=\"sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49\" crossorigin=\"anonymous\"></script>"
    echo "<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js\" integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\" crossorigin=\"anonymous\"></script>"
echo "</body>"
    echo "</html>"
