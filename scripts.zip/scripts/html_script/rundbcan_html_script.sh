#!/bin/bash

var=${1}
var2=${2}
i=${var}/Software/output/run_dbcan/${var2}/overview.tsv
    
    echo "<!DOCTYPE html>"
    echo "<html>"
    echo "<head>"
    echo "<meta charset=\"utf-8\">"
    echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">"
    echo "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css\" integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">"
    echo "<title>${i}</title>"
    echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css\"/>"
    echo "<script src=\"https://code.jquery.com/jquery-3.5.1.js\"></script>"
echo "<script src=\"https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js\"></script>"

    echo "<script type=\"text/javascript\" charset=\"utf-8\">"
    echo "\$(document).ready(function() {"
    echo "\$('#test').dataTable();"
    echo "} );"
    echo "</script>"
    echo "<style>"
    echo "td,tr,th {"
    echo    "font-size: 11px;"
    echo "width: 100%;"
    echo "display: fixed;"
    echo  "}"
    echo "</style>"
    echo "</head>"
    echo "<body>"
    echo "<div id=\"data\">"
    echo "<table id=\"test\" class=\"display\">"
    echo "<thead>"
    ln=1
    OIFS=$IFS
    IFS=$'\t'
    counter=1
    counter2=1
    while read line
    do
        echo "<tr>"
        for word in $line
        do
            if [ $ln -eq 1 ]
            then
                echo "<th>$word</th>"
                counter=$((counter+1))
                if [ $counter -eq 7 ]
                then
                    echo "</tr>"
                    echo "</thead>"
                fi
            else
                echo "<td>$word</td>"

                # counter2=$((counter2+1))
                # if [ $counter2 -eq 16 ]
                # then
                #     echo "</tr>"
                    
                # fi
            fi
        done
        
        echo "</tr>"
        let ln=ln+1
    done<$i
    IFS=$OIFS
    echo "</table>"
    echo "</div>"
   echo "<script src=\"https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js\" integrity=\"sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49\" crossorigin=\"anonymous\"></script>"
    echo "<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js\" integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\" crossorigin=\"anonymous\"></script>"
echo "</body>"
    echo "</html>"

