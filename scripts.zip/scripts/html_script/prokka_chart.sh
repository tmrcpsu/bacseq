#!/bin/bash
var=${1}
for i in $var/Software/output/prokka/*/*.txt; do
# for i in /home/pbga/NetBeansProjects/BacSeq/Software/output/prokka/*/*.txt; do
filename=$(basename "$i" .txt)
file_name2+=("${filename[@]}")
comma=","
x=$(grep -rw $i -e 'CDS')
y=$(tr -dc '0-9' <<< $x)
value2+=("${y[@]}")

gene=$(grep -rw $i -e 'gene')
gene2=$(tr -dc '0-9' <<< $gene)
gene3+=("${gene2[@]}")

misc_RNA=$(grep -rw $i -e 'misc_RNA')
misc_RNA2=$(tr -dc '0-9' <<< $misc_RNA)
misc_RNA3+=("${misc_RNA2[@]}")


rRNA=$(grep -rw $i -e 'rRNA')
rRNA2=$(tr -dc '0-9' <<< $rRNA)
rRNA3+=("${rRNA2[@]}")

tRNA=$(grep -rw $i -e 'tRNA')
tRNA2=$(tr -dc '0-9' <<< $tRNA)
tRNA3+=("${tRNA2[@]}")

tmRNA=$(grep -rw $i -e 'tmRNA')
tmRNA2=$(tr -dc '0-9' <<< $tmRNA)
tmRNA3+=("${tmRNA2[@]}")

test+=$(cat $i | awk '{print $1}'| sed 's/$/     /')
done

str=$(printf "'%s', " "${file_name2[@]}" | sed 's/\(.*\),/\1 /')
str2=$(printf "%s," "${value2[@]}" | sed 's/\(.*\),/\1 /')
gene4=$(printf "%s," "${gene3[@]}" | sed 's/\(.*\),/\1 /')
misc_RNA4=$(printf "%s," "${misc_RNA3[@]}" | sed 's/\(.*\),/\1 /')
tRNA4=$(printf "%s," "${tRNA3[@]}" | sed 's/\(.*\),/\1 /')
tmRNA4=$(printf "%s," "${tmRNA3[@]}" | sed 's/\(.*\),/\1 /')
grep_header=$(printf "%s" "${test[@]}" | tr ' ' '\n' | awk '!x[$0]++' | sed s/://g)
rRNA4=$(printf "%s," "${rRNA3[@]}" | sed 's/\(.*\),/\1 /')


echo "<!DOCTYPE html>"
    echo "<html>"
    echo "<head>"
    echo "<meta charset=\"utf-8\">"
    echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">"
    echo "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css\" integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">"
    echo "<title>Prokka Chart</title>"
    #echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css\"/>"
    echo "<script src=\"https://code.jquery.com/jquery-3.5.1.js\"></script>"
echo "<script src=\"https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js\"></script>"

   
    echo "</head>"
    echo "<body>"
    echo "<div>"
    echo  "<canvas id=\"myChart4\" style=\"position: relative; height:300px; width:700px;\"></canvas>"
    echo "</div>"
   echo "<script src=\"https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js\" integrity=\"sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49\" crossorigin=\"anonymous\"></script>"
  echo "<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js\" integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\" crossorigin=\"anonymous\"></script>"
 echo "<script>"
 echo "var labels = [${str}];"
	echo "var data = [${str2}];"
	echo "var gene_data = [${gene4}];"
    echo "var misc_RNA_data = [${misc_RNA4}];"
   echo "var tRNA_data = [${tRNA4}];"
   echo "var tmRNA_data = [${tmRNA4}];"
   echo "var rRNA_data = [${rRNA4}];"
    echo "const mixed_ctx = document.getElementById(\"myChart4\").getContext('2d');"
	

    echo "var chart = new Chart(mixed_ctx, {
   type: 'bar',
   data: {
      labels: labels, // responsible for how many bars are gonna show on the chart
      // create 12 datasets, since we have 12 items
      // data[0] = labels[0] (data for first bar - 'Standing costs') | data[1] = labels[1] (data for second bar - 'Running costs')
      // put 0, if there is no data for the particular bar
      datasets: [{
         label: 'tmRNA',
         data: tmRNA_data,
         backgroundColor: '#242F9B'
      }, {
         label: 'tRNA',
         data: tRNA_data,
         backgroundColor: '#caf270'
      },{
         label: 'rRNA',
         data: rRNA_data,
         backgroundColor: '#FFDB5C'
      }, {
         label: 'misc_RNA',
         data: misc_RNA_data,
         backgroundColor: '#45c490'
  
      }, {
         label: 'Gene',
         data: gene_data,
         backgroundColor: '#008d93'
      }, {
         label: 'CDS',
         data: data,
         backgroundColor: '#2e5468'
      }]
   },
   options: {
      responsive: true,
      legend: {
         position: 'top' // place legend on the right side of chart
      },
      scales: {
         xAxes: [{
            stacked: true // this should be set to make the bars stacked
         }],
         yAxes: [{
    stacked: true,
    ticks: {
      beginAtZero: false,
    },
  }]
      }
   }
});"


    echo "</script>"
   
echo "</body>"
    echo "</html>"


